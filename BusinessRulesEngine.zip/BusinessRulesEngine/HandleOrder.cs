﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessRulesEngine
{
    public class HandleOrder
    {
        public RuleResponse handleOrder(OrderDetails order)
        {
            OrderProcessor orderProcessor = null;
            switch (order.OrderType)
            {
                case OrderType.PHYSICAL_PRODUCT:
                    orderProcessor = new PhysicalProductHandler();
                    break;                
            }
            return orderProcessor.processOrder(order);
        }
    }
}
