﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessRulesEngine
{
    public abstract class OrderProcessor
    {

        public abstract RuleResponse processOrder(OrderDetails order);

        protected void sendEmail(string emailAddress, string subject, string body)
        {
            Console.WriteLine("Email is sent");
        }

        protected void sendEmail(string emailAddress, string subject, string body, FileStream attachment)
        {
            Console.WriteLine("Email sent with attachments..");
        }


    }
}
